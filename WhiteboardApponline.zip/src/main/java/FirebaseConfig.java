import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class FirebaseConfig {
    private static DatabaseReference database;

    public static void initializeFirebase() {
        try {
            // 環境変数からFirebase設定を取得
            String firebaseConfig = System.getenv("FIREBASE_CONFIG");

            if (firebaseConfig == null || firebaseConfig.isEmpty()) {
                throw new IllegalArgumentException("環境変数 'FIREBASE_CONFIG' が設定されていません");
            }

            // FirebaseOptionsを設定
            ByteArrayInputStream serviceAccount = new ByteArrayInputStream(firebaseConfig.getBytes(StandardCharsets.UTF_8));
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl("https://whiteboardapp-503d8-default-rtdb.firebaseio.com/")
                    .build();

            // FirebaseAppの初期化
            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
                System.out.println("Firebase の初期化に成功しました");
            }

            // データベース参照の取得
            database = FirebaseDatabase.getInstance().getReference();
        } catch (Exception e) {
            System.err.println("Firebase の初期化に失敗しました");
            e.printStackTrace();
        }
    }

    public static DatabaseReference getDatabase() {
        if (database == null) {
            throw new IllegalStateException("Firebase が初期化されていません。initializeFirebase を呼び出してください。");
        }
        return database;
    }
}
