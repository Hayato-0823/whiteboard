public class TextBoxData {
    public int x, y, width, height;
    public String text;

    public TextBoxData() {} // Firebase 用の空のコンストラクタ

    public TextBoxData(int x, int y, int width, int height, String text) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.text = text;
    }
}
